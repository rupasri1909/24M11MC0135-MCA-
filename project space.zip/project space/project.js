const inputVal = document.getElementById('input-val');
const secondCont = document.getElementById('second-cont');


const menCollection = [
    {
        name:"Us Polo",
        shirtUrl : "./shirt1.avif",
        prize: 12000,
        Rating: 4.3
    },
    {
        name:"Souled Store",
        shirtUrl : "./shirt2.avif",
        prize: 15000,
        Rating: 4.1
    },
    {
        name:"Bewakoof",
        shirtUrl : "./shirt3.avif",
        prize: 10000,
        Rating: 4.0
    },
    {
        name:"Bluorng",
        shirtUrl : "./shirt4.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Lee cooper",
        shirtUrl : "./shirt5.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Snitch",
        shirtUrl : "./shirt6.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Powerlook",
        shirtUrl : "./shirt7.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Indian Gaurage",
        shirtUrl : "./shirt8.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"H&M",
        shirtUrl : "./shirt3.avif",
        prize: 9000,
        Rating: 4.5
    },
]

let previousState = ''; 

        function recall() {
            const secondCont = document.getElementById('second-cont');
            secondCont.innerHTML = previousState; 
        }

        function shirtsFun() {
          
            const secondCont = document.getElementById('second-cont');
            previousState = secondCont.innerHTML; 
            secondCont.innerHTML = '';

            menCollection.map((val) => {
                const addDiv = `<div class="product-box">
                        <div class="img-box">
                            <img src="${val.shirtUrl}" />
                        </div>
                        <h2 class="product-title raleway-font">${val.name}</h2>
                        <div class="price-and-cart">
                            <span class="price">${val.prize}</span>
                            <i class="ri-shopping-bag-line add-cart"></i>
                        </div>
                    </div>`;
                secondCont.innerHTML += addDiv;
            });

            let backBtn = document.createElement("button");
            backBtn.textContent = "Back";
            backBtn.classList = "buttonStyle";
            backBtn.onclick = function() {
                recall();
            };
            secondCont.appendChild(backBtn);
        }

        shirtsFun();

const tshirtCollection = [
    {name:"Us Polo",shirtUrl : "./overt1.avif",prize: 12000,Rating: 4.3},
    {name:"Souled Store",shirtUrl : "./overt2.avif",prize: 15000,Rating: 4.1},
    {name:"Bewakoof",shirtUrl : "./overt3.avif",prize: 10000,Rating: 4.0},
    {name:"Bluorng",shirtUrl : "./overt4.avif",prize: 9000,Rating: 4.5},
    {name:"Snitch",shirtUrl : "./overt5.avif",prize: 9000,Rating: 4.5},
    {name:"Powerlook",shirtUrl : "./overt6.avif",prize: 9000,Rating: 4.5},
    {name:"Teamspirit",shirtUrl : "./overt7.webp",prize: 9000,Rating: 4.5},
    {name:"Netplay",shirtUrl : "./overt8.avif",prize: 9000,Rating: 4.5},
    {name:"Bluorng",shirtUrl : "./overt9.avif",prize: 9000,Rating: 4.5},
]

function tshirtsFun (){
    const secondCont = document.getElementById('second-cont');
    secondCont.innerHTML='';
    tshirtCollection.map((val)=>{
        const addDiv = `<div class="product-box">
                <div class="img-box">
                    <img src="${val.shirtUrl}" />
                </div>
                <h2 class="product-title raleway-font">${val.name}</h2>
                <div class="price-and-cart">
                    <span class="price">${val.prize}</span>
                    <i class="ri-shopping-bag-line add-cart"></i>
                </div>
            </div>`
            secondCont.innerHTML+= addDiv
    })
}
const jeansCollection = [
    {
        name:"Us Polo",
        shirtUrl : "./bjeans1.avif",
        prize: 12000,
        Rating: 4.3
    },
    {
        name:"Souled Store",
        shirtUrl : "./bjeans2.avif",
        prize: 15000,
        Rating: 4.1
    },
    {
        name:"Bewakoof",
        shirtUrl : "./bjeans3.avif",
        prize: 10000,
        Rating: 4.0
    },
    {
        name:"Bluorng",
        shirtUrl : "./bjeans4.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Snitch",
        shirtUrl : "./bjeans1.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Powerlook",
        shirtUrl : "./bjeans5.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Teamspirit",
        shirtUrl : "./bjeans6.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Netplay",
        shirtUrl : "./bjeans7.avif",
        prize: 9000,
        Rating: 4.5
    },
    {
        name:"Bluorng",
        shirtUrl : "./bjeans8.avif",
        prize: 9000,
        Rating: 4.5
    },
]

function jeansFun (){
    const secondCont = document.getElementById('second-cont');
    secondCont.innerHTML='';
    jeansCollection.map((val)=>{
        const addDiv = `<div class="product-content">
        <div class="product-box">
                <div class="img-box">
                    <img src="${val.shirtUrl}" />
                </div>
                <h2 class="product-title raleway-font">${val.name}</h2>
                <div class="price-and-cart">
                    <span class="price">${val.prize}</span>
                    <i class="ri-shopping-bag-line add-cart"></i>
                </div>
            </div>
            </div>`
            secondCont.innerHTML+= addDiv
    })
}